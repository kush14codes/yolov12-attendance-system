# face recognitiom > 2024-07-06 8:46am
https://universe.roboflow.com/tugasan/face-recognitiom

Provided by a Roboflow user
License: CC BY 4.0

